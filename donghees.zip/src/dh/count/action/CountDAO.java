package dh.count.action;

public class CountDAO {

		
		public int getDh_num() {
		return dh_num;
	}
	public void setDh_num(int dh_num) {
		this.dh_num = dh_num;
	}
	public String getDh_name() {
		return dh_name;
	}
	public void setDh_name(String dh_name) {
		this.dh_name = dh_name;
	}
	public String getDh_subject() {
		return dh_subject;
	}
	public void setDh_subject(String dh_subject) {
		this.dh_subject = dh_subject;
	}
	public String getDh_content() {
		return dh_content;
	}
	public void setDh_content(String dh_content) {
		this.dh_content = dh_content;
	}
	public int getDh_pos() {
		return dh_pos;
	}
	public void setDh_pos(int dh_pos) {
		this.dh_pos = dh_pos;
	}
	public int getDh_depth() {
		return dh_depth;
	}
	public void setDh_depth(int dh_depth) {
		this.dh_depth = dh_depth;
	}
	public int getDh_ref() {
		return dh_ref;
	}
	public void setDh_ref(int dh_ref) {
		this.dh_ref = dh_ref;
	}
	public String getDh_regdate() {
		return dh_regdate;
	}
	public void setDh_regdate(String dh_regdate) {
		this.dh_regdate = dh_regdate;
	}
	public String getDh_pass() {
		return dh_pass;
	}
	public void setDh_pass(String dh_pass) {
		this.dh_pass = dh_pass;
	}
	public String getDh_ip() {
		return dh_ip;
	}
	public void setDh_ip(String dh_ip) {
		this.dh_ip = dh_ip;
	}
	public int getDh_count() {
		return dh_count;
	}
	public void setDh_count(int dh_count) {
		this.dh_count = dh_count;
	}
	public String getDh_filename() {
		return dh_filename;
	}
	public void setDh_filename(String dh_filename) {
		this.dh_filename = dh_filename;
	}
	public int getDh_filesize() {
		return dh_filesize;
	}
	public void setDh_filesize(int dh_filesize) {
		this.dh_filesize = dh_filesize;
	}
		private int dh_num;
		private String dh_name;        
		private String dh_subject;      
		private String dh_content;     
		private int dh_pos;            
		private int dh_depth;        
		private int dh_ref;        
		private String dh_regdate;     
		private String dh_pass;          
		private String  dh_ip;
		private int dh_count;        
		private String dh_filename; 
		private int dh_filesize;
}
		